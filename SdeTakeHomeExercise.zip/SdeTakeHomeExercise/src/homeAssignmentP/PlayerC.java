package homeAssignmentP;

public class PlayerC {
	private String name;
	private int bonusRoll = 0;
	private int miniBonusRoll = 0;
	private int totalScore = 0;
	
	public PlayerC(String s) {
		this.name = s;
	}
	
	public PlayerC(String s, int br, int mbr) {
		this.name = s;
		this.bonusRoll = br;
		this.miniBonusRoll = mbr;
	}
	
	public void addBonusRoll(int n) {
		bonusRoll += n;
	}
	
	public void addMiniBonusRoll(int n) {
		miniBonusRoll += n;
	}
	
	public void addTotalScore(int n) {
		totalScore += n;
	}
	
	public String getName() {
		return this.name;
	}
	
	public int getBonusRoll() {
		return bonusRoll;
	}
	
	public int getMiniBonusRoll() {
		return miniBonusRoll;
	}
	
	public int getTotalScore() {
		return totalScore;
	}
	
}
