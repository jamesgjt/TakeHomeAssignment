package homeAssignmentP;

import java.util.ArrayDeque;
import java.util.Iterator;


public class RoundC {
	private ArrayDeque<TurnC> turns = new ArrayDeque<TurnC>();
	private int bonusNum = 0;
	private int miniBonusNum = 0;
	private int totalTurnScores = 0;
	private String name;
	private int currentRound; 
	
	public RoundC(String name, int round) {
		this.name = name;
		this.currentRound = round;
	}
	
	/**
	 * start a round with predetermine turns and result
	 * @param name
	 * @param round
	 * @param t
	 */
	public RoundC(String name, int round, ArrayDeque<TurnC> t) {
		this.name = name;
		this.currentRound = round;
		this.turns = t;
		
		System.out.println( this.name+":");
		Iterator<TurnC> itr = turns.iterator();
		while(itr.hasNext()) {
			TurnC x = itr.next();
			System.out.println(x.getAllDicesResults());
		}
		calculateScore();
		System.out.println("round-"+this.currentRound+": "+this.name+" earns: "+this.totalTurnScores);
	}
	
	/**
	 * play the round with turn(s)
	 */
	public void startRound() {
		System.out.println( this.name+":");
		while(true) {
			TurnC t = new TurnC(this.currentRound);
			int score = t.getTurnScore();
			System.out.println(t.getAllDicesResults()+", "+score);
			turns.add(t);
			if (score == 0)
				break;
		}
		calculateScore();
		System.out.println("round-"+this.currentRound+ ":" + this.name+ " earns: "+this.totalTurnScores);
	}
	
	private void calculateScore() {
		TurnC lastT = turns.peekLast();
		if(turns.size() == 1 && lastT.getTurnScore() == 0) {
			turns.removeLast();
			return;
		}
		else if(lastT.getTurnScore() == 0) {
			turns.removeLast();
			lastT = turns.peekLast();
		}
		if (lastT.isBonus() || lastT.isMiniBonus()) {
			turns.removeLast();//Exception_Rule where only keep the point if the roll imm after has scored point(s)
		}
		//set up params for counting scores, bonus & miniBonus rolls
		Iterator<TurnC> itr = turns.iterator();
		while(itr.hasNext()) {
			TurnC t = itr.next();
			if (t.isBonus())
				this.bonusNum++;
			if(t.isMiniBonus())
				this.miniBonusNum++;
			this.totalTurnScores += t.getTurnScore();
		}
	}
	
	public int getRoundBonusNum() {
		return this.bonusNum;
	}
	
	public int getRoundMiniBonusNum() {
		return this.miniBonusNum;
	}
	
	public int getRoundScore() {
		return this.totalTurnScores;
	}
	
	public String getPlayerName() {
		return this.name;
	}
	
	public static void main(String[] arg) {
//		RoundC r1 = new RoundC("James", 1);
//		r1.startRound();
		
		TurnC t1 = new TurnC(1, new DiceC(2), new DiceC(3), new DiceC(4));//end
		TurnC t2 = new TurnC(1, new DiceC(1), new DiceC(1), new DiceC(1));//bonus
		TurnC t3 = new TurnC(1, new DiceC(2), new DiceC(2), new DiceC(2));//mini bonus
		TurnC t4 = new TurnC(1, new DiceC(2), new DiceC(3), new DiceC(1));//1 pt
		TurnC t5 = new TurnC(1, new DiceC(1), new DiceC(1), new DiceC(2));//2pt
		ArrayDeque<TurnC> ts2 = new ArrayDeque<TurnC>();
		ts2.add(t3);
		ts2.add(t1);
		RoundC r2= new RoundC("James", 1, ts2);
		ts2.clear();
		ts2.add(t3);
		ts2.add(t2);
		ts2.add(t1);
		r2= new RoundC("James", 1, ts2);
		System.out.println("bonus:"+r2.getRoundBonusNum()+", mini:"+r2.getRoundMiniBonusNum());
		System.exit(0);
	}
	
}
