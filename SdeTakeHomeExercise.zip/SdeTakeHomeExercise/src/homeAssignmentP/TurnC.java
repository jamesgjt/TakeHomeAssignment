package homeAssignmentP;

import java.util.ArrayList;
import java.util.List;

public class TurnC{
	public static final int numOfDice = 3;
	private List<DiceC> dices = new ArrayList<DiceC>();
	private int currentRound;
	
	/**
	 * constructor of Turn
	 * @param round
	 */
	public TurnC(int round) {
		this.currentRound = round;
		for (int i = 0; i < numOfDice; i ++) {
			DiceC aDice = new DiceC();
			dices.add(aDice);
		}
	}
	
	/**
	 * testing constructor
	 * @param round
	 * @param a
	 * @param b
	 * @param c
	 */
	public TurnC(int round, DiceC a, DiceC b, DiceC c) {
		this.currentRound = round;
		dices.add(a);
		dices.add(b);
		dices.add(c);
	}
	
	/**
	 * return list of dice face results
	 * @return return list of dice face results
	 */
	public List<Integer> getAllDicesResults(){
		List<Integer> l = new ArrayList<Integer>();
		for(int i = 0; i < this.dices.size(); i ++)
			l.add(this.dices.get(i).getResult());
		return l;
	}
	
	/**
	 * return the dice in list contain all the same result number
	 * @return if the turn roll all dice with same face
	 */
	private boolean hasSameFaceVal() {
		boolean ret = true;
		int pt = dices.get(0).getResult();
		for (int i = 0; i < dices.size(); i ++) {
			int aDiceRes= dices.get(i).getResult();
			if(pt != aDiceRes) {
				return false;
			}
		}
		return ret;
	}
	
	/**
	 * To be Bonus turn, it must be same face and are same as current round
	 * @return if the turn roll a bonus
	 */
	public boolean isBonus() {
		int pt = dices.get(0).getResult();
		return hasSameFaceVal() && (pt == this.currentRound);
	}
	
	public boolean isMiniBonus() {
		int pt = dices.get(0).getResult();
		return hasSameFaceVal() && (pt != this.currentRound);
	}
	
	/**
	 * this return the turn scoring with no bonus or no miniBonus
	 * @return the turn scoring without the bonus or miniBonus
	 */
	private int countScore() {
		int s = 0;
		for (int i = 0; i < dices.size(); i ++) {
			int diceRes = dices.get(i).getResult();
			if (diceRes == this.currentRound)
				s++;
		}
		return s;
	}
	/**
	 * This will check if the turn is bonus or miniBonus or neither and return the score
	 * @return the turn score
	 */
	public int getTurnScore() {
		int score = 0;
		if (isBonus()) { //bonus case
			score = 11;
		}
		else if (hasSameFaceVal()) {//since not bonus has been catch, this eq minibonus
			score = 5;
		}
		else {
			score = countScore();
		}
		
		return score;
	}
	
	public static void main(String[] arg) {
		TurnC t = new TurnC(1);
		System.out.println("r:"+t.currentRound+" score:"+t.getTurnScore());
		System.out.println(""+t.getAllDicesResults());
		System.out.println("bonus:"+t.isBonus()+",miniB:"+t.isMiniBonus());

		
		TurnC t2 = new TurnC(2, new DiceC(2), new DiceC(2), new DiceC(2));
		System.out.println("r:"+t2.currentRound+" score:"+t2.getTurnScore());
		System.out.println(""+t2.getAllDicesResults());
		System.out.println("bonus:"+t2.isBonus()+",miniB:"+t2.isMiniBonus());
		
		TurnC t3 = new TurnC(1, new DiceC(5), new DiceC(5), new DiceC(5));
		System.out.println("r:"+t3.currentRound+" score:"+t3.getTurnScore());
		System.out.println(""+t3.getAllDicesResults());
		System.out.println("bonus:"+t3.isBonus()+",miniB:"+t3.isMiniBonus());
		System.exit(0);
		
	}
	

}
