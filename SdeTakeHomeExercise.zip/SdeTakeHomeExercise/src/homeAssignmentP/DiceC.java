package homeAssignmentP;
import java.util.Random;

public class DiceC{
	private int result;
	public static final int minVal = 1;
	public static final int maxVal = 6;
	
	/**
	 * constructor
	 */
	public DiceC() {
		Random ran = new Random();
		result = ran.nextInt(maxVal)+minVal;
	}
	
	/**
	 * testing constructor
	 * @param r
	 */
	public DiceC(int r) {
		if (r<=maxVal && r>=minVal) {
			result = r;
		}
		else {
			System.out.println("wrong input, set default result to 1");
			result = 1;
		}
	}
	
	/**
	 * 
	 * @return dice roll result
	 */
	public int getResult() {
		return this.result;
	}
	
	public static void main(String[] arg) {
		DiceC c = new DiceC(1);
		System.out.println(""+c.getResult());
		c = new DiceC();
		System.out.println(""+c.getResult());
		c = new DiceC(0);
		System.out.println(""+c.getResult());
		System.exit(0);
	}

}

