package homeAssignmentP;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayDeque;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class DiceTests {

	@Test
	void test() {

		System.out.println("TurnC Testing Start");
		TurnC zeroPt = new TurnC(1, new DiceC(2), new DiceC(3), new DiceC(4));
		Assertions.assertFalse(zeroPt.isBonus());
		Assertions.assertFalse(zeroPt.isMiniBonus());
		Assertions.assertEquals(0, zeroPt.getTurnScore());
		
		TurnC bonusTurn = new TurnC(2, new DiceC(2), new DiceC(2), new DiceC(2));
		Assertions.assertTrue(bonusTurn.isBonus());
		Assertions.assertFalse(bonusTurn.isMiniBonus());
		Assertions.assertEquals(11, bonusTurn.getTurnScore());
		
		TurnC miniBonusTurn = new TurnC(5, new DiceC(4), new DiceC(4), new DiceC(4));
		Assertions.assertFalse(miniBonusTurn.isBonus());
		Assertions.assertTrue(miniBonusTurn.isMiniBonus());
		Assertions.assertEquals(5, miniBonusTurn.getTurnScore());
		
		TurnC onePt = new TurnC(4, new DiceC(2), new DiceC(3), new DiceC(4));
		Assertions.assertFalse(onePt.isBonus());
		Assertions.assertFalse(onePt.isMiniBonus());
		Assertions.assertEquals(1, onePt.getTurnScore());
		
		TurnC twoPt = new TurnC(3, new DiceC(3), new DiceC(3), new DiceC(4));
		Assertions.assertFalse(twoPt.isBonus());
		Assertions.assertFalse(twoPt.isMiniBonus());
		Assertions.assertEquals(2, twoPt.getTurnScore());
		//testing RoundC
		
		System.out.println("RoundC Testing Start");
		zeroPt = new TurnC(1, new DiceC(2), new DiceC(3), new DiceC(4));//end
		bonusTurn = new TurnC(1, new DiceC(1), new DiceC(1), new DiceC(1));//bonus
		miniBonusTurn = new TurnC(1, new DiceC(2), new DiceC(2), new DiceC(2));//mini bonus
		onePt = new TurnC(1, new DiceC(2), new DiceC(3), new DiceC(1));//1 pt
		twoPt = new TurnC(1, new DiceC(1), new DiceC(1), new DiceC(2));//2pt
		
		ArrayDeque<TurnC> ts1 = new ArrayDeque<TurnC>();
		ts1.add(zeroPt);
		
		RoundC r1 = new RoundC("James", 1, ts1);
		Assertions.assertEquals(0, r1.getRoundScore());
		Assertions.assertEquals(0, r1.getRoundBonusNum());
		Assertions.assertEquals(0, r1.getRoundMiniBonusNum());
		ts1.clear();
		ts1.add(bonusTurn);
		ts1.add(zeroPt);
		r1 = new RoundC("James", 1, ts1);
		Assertions.assertEquals(0, r1.getRoundScore());
		Assertions.assertEquals(0, r1.getRoundBonusNum());
		Assertions.assertEquals(0, r1.getRoundMiniBonusNum());
		ts1.clear();
		ts1.add(miniBonusTurn);
		ts1.add(zeroPt);
		r1 = new RoundC("James", 1, ts1);
		Assertions.assertEquals(0, r1.getRoundScore());
		Assertions.assertEquals(0, r1.getRoundBonusNum());
		Assertions.assertEquals(0, r1.getRoundMiniBonusNum());
		
		
		ArrayDeque<TurnC> ts2 = new ArrayDeque<TurnC>();
		ts2.add(onePt);
		ts2.add(twoPt);
		ts2.add(zeroPt);
		RoundC r2 = new RoundC("James", 1, ts2);
		Assertions.assertEquals(3, r2.getRoundScore());
		Assertions.assertEquals(0, r2.getRoundBonusNum());
		Assertions.assertEquals(0, r2.getRoundMiniBonusNum());
		ts2.clear();
		
		ts2.add(miniBonusTurn);
		ts2.add(bonusTurn);
		ts2.add(onePt);
		ts2.add(zeroPt);
		r2 = new RoundC("James", 1, ts2);
		Assertions.assertEquals(17, r2.getRoundScore());
		Assertions.assertEquals(1, r2.getRoundBonusNum());
		Assertions.assertEquals(1, r2.getRoundMiniBonusNum());
		
		ArrayDeque<TurnC> ts3 = new ArrayDeque<TurnC>();
		ts3.add(miniBonusTurn);
		ts3.add(bonusTurn);
		ts3.add(zeroPt);
		RoundC r3 = new RoundC("James", 1, ts3);
		Assertions.assertEquals(5, r3.getRoundScore());
		Assertions.assertEquals(0, r3.getRoundBonusNum());
		Assertions.assertEquals(1, r3.getRoundMiniBonusNum());
		
		
		//test game
		
		System.out.println("GamePlayC Testing Start");
		PlayerC p1 = new PlayerC("James");
		p1.addTotalScore(onePt.getTurnScore());//1 pt
		PlayerC p2 = new PlayerC("Katie");
		p2.addTotalScore(twoPt.getTurnScore());// 2 pt
		GamePlayC game = new GamePlayC(p1, p2);
		game.setWinner();
		System.out.println(game.getWinnerMessage());
		Assertions.assertEquals(game.getWinner().getTotalScore(),2);
		Assertions.assertEquals(p2.getName()+GamePlayC.winByScore,game.getWinnerMessage());
		
		p1.addTotalScore(miniBonusTurn.getTurnScore());//6 pt
		p1.addMiniBonusRoll(1);
		p2.addTotalScore(twoPt.getTurnScore());
		p2.addTotalScore(twoPt.getTurnScore());//6pt
		game = new GamePlayC(p1, p2);
		game.setWinner();
		System.out.println(game.getWinnerMessage());
		Assertions.assertEquals(game.getWinner().getTotalScore(),6);
		Assertions.assertEquals(game.getWinner().getMiniBonusRoll(),1);
		Assertions.assertEquals(p1.getName()+GamePlayC.winByMini,game.getWinnerMessage());
		
		p1 = new PlayerC("James");
		p1.addTotalScore(bonusTurn.getTurnScore());//11 pt
		p1.addBonusRoll(1);
		p2.addTotalScore(twoPt.getTurnScore());
		p2.addTotalScore(twoPt.getTurnScore());
		p2.addTotalScore(onePt.getTurnScore());//11pt
		game = new GamePlayC(p1, p2);
		game.setWinner();
		System.out.println(game.getWinnerMessage());
		Assertions.assertEquals(game.getWinner().getTotalScore(),11);
		Assertions.assertEquals(game.getWinner().getBonusRoll(),1);
		Assertions.assertEquals(p1.getName()+GamePlayC.winByBonus,game.getWinnerMessage());
		
		p1 = new PlayerC("James");
		p1.addTotalScore(bonusTurn.getTurnScore());//11 pt
		p1.addBonusRoll(1);
		p2 = new PlayerC("Katie");
		p2.addTotalScore(bonusTurn.getTurnScore());//11 pt
		p2.addBonusRoll(1);
		game = new GamePlayC(p1, p2);
		game.setWinner();
		System.out.println(game.getWinnerMessage());
		Assertions.assertEquals(game.getWinner().getTotalScore(),11);
		Assertions.assertEquals(game.getWinner().getBonusRoll(),1);
		Assertions.assertEquals(game.getWinner().getName()+GamePlayC.winByTieBreaker,game.getWinnerMessage());
		
		p1 = new PlayerC("James");
		p2 = new PlayerC("Katie");
		game = new GamePlayC(p1, p2);
		game.setWinner();
		System.out.println(game.getWinnerMessage());
		Assertions.assertEquals(game.getWinner().getTotalScore(),0);
		Assertions.assertEquals(game.getWinner().getBonusRoll(),0);
		Assertions.assertEquals(game.getWinner().getMiniBonusRoll(),0);
		
		
	}

}
