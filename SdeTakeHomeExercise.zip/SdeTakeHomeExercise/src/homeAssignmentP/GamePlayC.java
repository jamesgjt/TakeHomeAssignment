package homeAssignmentP;

import java.util.Scanner;

public class GamePlayC {
	
	public static final int minRound = 1;
	public static final int maxRounds = 6;
	public static final String winByScore = " won by having higher Score";
	public static final String winByBonus = " won by having more Bonus Roll(s)";
	public static final String winByMini = " won by having more Mini Roll(s)";
	public static final String winByTieBreaker = " won in Tie Breaker";
	
	private PlayerC p1 = null;
	private PlayerC p2 = null;
	
	private PlayerC gameWinner = null;
	public String winnerMessage = "";
	
	public GamePlayC(String p1Name, String p2Name) {
		p1 = new PlayerC(p1Name);
		p2 = new PlayerC(p2Name);
	}
	
	public GamePlayC(PlayerC a, PlayerC b) {
		p1 = a;
		p2 = b;
	}
	
	public void startGame() {
		for(int i = minRound; i <= maxRounds; i ++ ) {
			System.out.println("Round "+i+":");
			RoundC r1 = new RoundC(p1.getName(), i);
			r1.startRound();
			p1.addBonusRoll(r1.getRoundBonusNum());
			p1.addMiniBonusRoll(r1.getRoundMiniBonusNum());
			p1.addTotalScore(r1.getRoundScore());
			
			RoundC r2 = new RoundC(p2.getName(), i);
			r2.startRound();
			p2.addBonusRoll(r2.getRoundBonusNum());
			p2.addMiniBonusRoll(r2.getRoundMiniBonusNum());
			p2.addTotalScore(r2.getRoundScore());
			System.out.println();
		}
		setWinner();
	}
	
	/**
	 * set the winner and how he wins the game
	 */
	public void setWinner() {
		printGameSummary();
		if (p1.getTotalScore() == p2.getTotalScore()) {
			if(p1.getBonusRoll() == p2.getBonusRoll()) {
				if (p1.getMiniBonusRoll() == p2.getMiniBonusRoll()) {
					runTieBreaker();
				}
				else {
					winnerMessage = winByMini;
					if (p1.getMiniBonusRoll() > p2.getMiniBonusRoll()) 
						gameWinner = p1;
					else 
						gameWinner = p2;
				}
			}
			else {
				winnerMessage = winByBonus;
				if(p1.getBonusRoll() > p2.getBonusRoll()) 
					gameWinner = p1;
				else 
					gameWinner = p2;
			}
		}
		else {
			winnerMessage = winByScore;
			if (p1.getTotalScore() > p2.getTotalScore())
				gameWinner = p1;
			else 
				gameWinner = p2;
		}
	}
	
	public void runTieBreaker() {
		System.out.println("Tie Breaker begins");
		while(true) {
			TurnC p1Turn = new TurnC(maxRounds);
//			TurnC p1Turn = new TurnC(maxRounds, new DiceC(maxRounds), new DiceC(maxRounds), new DiceC(maxRounds));//test tie breaker 
			System.out.println(p1.getName()+" rolls "+p1Turn.getAllDicesResults()+" earns:"+p1Turn.getTurnScore());
			TurnC p2Turn = new TurnC(maxRounds);
			System.out.println(p2.getName()+" rolls "+p2Turn.getAllDicesResults()+" earns:"+p2Turn.getTurnScore());
			if (p1Turn.getTurnScore() == p2Turn.getTurnScore()) {
				continue;
			}
			else if (p1Turn.getTurnScore() > p2Turn.getTurnScore()) {
				gameWinner = p1;
				winnerMessage = winByTieBreaker;
			}
			else {
				gameWinner = p2;
				winnerMessage = winByTieBreaker;
			}
			break;
		}
	}
	
	public void printGameSummary() {
		System.out.println("Game Summary:");
		System.out.println(p1.getName()+" Scores:" +p1.getTotalScore()+ ", Bonus Roll(s):"+ 
		p1.getBonusRoll()+ ", Minibonus Roll(s):"+p1.getMiniBonusRoll());
		System.out.println(p2.getName()+" Scores:" +p2.getTotalScore()+ ", Bonus Roll(s):"+
		p2.getBonusRoll()+ ", Minibonus Roll(s):"+p2.getMiniBonusRoll());
	}
	
	public PlayerC getWinner() {
		return this.gameWinner;
	}
	
	public PlayerC getPlayer(String name) {
		if (p1.getName().equalsIgnoreCase(name))
			return p1;
		if (p2.getName().equalsIgnoreCase(name))
			return p2;
		return null;
	}
	
	public int getGameScore(String name) {
		return getPlayer(name).getTotalScore();
	}
	
	public int getGameBonusRoll(String name) {
		return getPlayer(name).getBonusRoll();
	}
	
	public int getGameMiniBonusRoll(String name) {
		return getPlayer(name).getMiniBonusRoll();
	}
	
	public String getWinnerMessage() {
		return gameWinner.getName() + winnerMessage;
	}

	public static void main(String[] arg) {
		
		System.out.println("Welcome to Dice Game Play!");
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter a player name:");
		String s1 = scn.nextLine();
		System.out.println("Enter another player name:");
		String s2 = scn.nextLine();
		
		PlayerC p1 = new PlayerC(s1);
		PlayerC p2 = new PlayerC(s2);
		GamePlayC game = new GamePlayC(p1, p2);
		game.startGame();
		System.out.println("Game Result:");
		System.out.println(game.getWinnerMessage());
		System.exit(0);
	}
}
