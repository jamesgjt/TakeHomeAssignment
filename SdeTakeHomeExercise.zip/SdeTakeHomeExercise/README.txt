Programe is built with EclipseIDE with JAVA 8 and UnitTest by JUnit5

Importing the Project:
1) Open Eclipse IDE
2) Choose "Import" -> "General" -> "Existing Project into Workspace"
3) Select the Directory of the project, ie SdeTakeHomeExercise


Setting Up Building Path of the Project:
1) Right Click project directory and select "Property"
2) Selet "Java Build Path"
3) In "Libraries" Tab, Make sure the build path includes JRE 8 and JUnit5
4) If not, Click "Add Library" to add them
5) Eclipse should start building automatically

Building the Project

Build and Run in Eclipse IDE
1) Select and Open src/homeAssignmentP/GamePlayC.java, which contains the starting of the program.
2) Choose "RUN"->"Run" or press Ctrl+f11 to run the program
3) If the Eclipse didn't build the project automatically during import, press Ctrl+B or selct "Project" -> "Build All"
3) For other Java file that contains main(), you can also modify it to run pre determined test cases for those class

4) For UnitTest, the DiceTest.java can be also run with same procedure
5) Please add or change the testcases in the UnitTest to test different scenerios

Export Executable JAR File
1) To Export into executables (Jar), Click "File" -> "Export"
2) Select "Runnable Jar File" 
3) Select "GamePlayC" as Launch and select a destination of Jar File and export

Running the Executable
1) open powershell and navigate into the jar file directory
2) run with command: java -jar ./EXE_JAR_NAME.jar

